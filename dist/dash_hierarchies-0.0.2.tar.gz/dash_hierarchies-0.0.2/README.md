# Dash Hierarchies

Dash Hierarchies is a Dash component library.

Intuitively display hierarchical data structures in a variety of ways. 

SimpleHierarchy
This component is used to display relative percentages of hierarchical data with a bar percentage below. 

https://github.com/user-attachments/assets/35cba725-e71b-4e8d-a907-23f01afb9c1e

TableHierarchy
This component is used to display hierarchical data in a tabular manner. Support for column selection is built-in. 

https://github.com/user-attachments/assets/43f7926e-c393-40f8-a7c7-51fe0bb7c9fa

